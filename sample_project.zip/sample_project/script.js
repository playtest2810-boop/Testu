function showMessage() {
  alert('Sample project is working!');
}
