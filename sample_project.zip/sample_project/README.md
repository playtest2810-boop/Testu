# Sample GitHub Project

This is a sample project generated for download.

## Files
- index.html
- style.css
- script.js
